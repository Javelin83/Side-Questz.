import type { EbayProduct, FlipProduct, RepairLevel } from "./types"
import { calculateRealProfit, getCategoryFees } from "./profit-calculator"

export function analyzeAutomotiveProduct(product: EbayProduct): FlipProduct {
  const title = product.title.toLowerCase()
  const condition = product.condition?.toLowerCase() || ""
  const price = product.price?.extracted || 0

  // Extract vehicle info from title
  const yearMatch = title.match(/\b(19|20)\d{2}\b/)
  const year = yearMatch ? yearMatch[0] : undefined

  // Common automotive keywords
  const carKeywords = ["car", "sedan", "coupe", "suv", "truck", "van", "wagon", "civic", "accord", "camry", "corolla"]
  const motorcycleKeywords = [
    "motorcycle",
    "bike",
    "harley",
    "yamaha",
    "kawasaki",
    "suzuki",
    "cruiser",
    "sportbike",
    "dirt bike",
    "scooter",
    "chopper",
    "touring bike",
  ]
  const partsKeywords = ["part", "engine", "transmission", "wheel", "tire", "bumper", "headlight"]

  let vehicleType: "car" | "motorcycle" | "truck" | "parts" | "other" = "other"

  if (partsKeywords.some((keyword) => title.includes(keyword))) {
    vehicleType = "parts"
  } else if (carKeywords.some((keyword) => title.includes(keyword))) {
    vehicleType = "car"
  } else if (motorcycleKeywords.some((keyword) => title.includes(keyword))) {
    vehicleType = "motorcycle"
  }

  // Automotive repair indicators
  const repairableKeywords = [
    "salvage",
    "rebuild",
    "project",
    "restoration",
    "parts",
    "repair",
    "damaged",
    "accident",
    "flood",
    "fire",
    "hail",
    "not running",
    "no start",
    "engine problem",
    "transmission",
    "needs work",
    "mechanic special",
    "fixer upper",
    "as-is",
    "for parts",
  ]

  const beginnerRepairs = [
    "battery",
    "starter",
    "alternator",
    "brakes",
    "oil change",
    "tune up",
    "spark plugs",
    "air filter",
    "belts",
    "hoses",
    "fluids",
    "minor dent",
    "scratches",
  ]

  const intermediateRepairs = [
    "engine",
    "transmission",
    "clutch",
    "suspension",
    "exhaust",
    "radiator",
    "ac",
    "electrical",
    "wiring",
    "body work",
    "paint",
    "interior",
    "seats",
  ]

  const expertRepairs = [
    "frame damage",
    "flood damage",
    "fire damage",
    "complete rebuild",
    "engine swap",
    "transmission rebuild",
    "major accident",
    "structural damage",
  ]

  let category: "flippable" | "repairable" = "flippable"
  let repairLevel: RepairLevel | undefined
  let repairEstimate: number | undefined
  let reason = ""
  let estimatedResaleValue = price * 1.3

  // Check if vehicle needs repair
  const hasRepairKeywords = repairableKeywords.some((keyword) => title.includes(keyword) || condition.includes(keyword))

  if (hasRepairKeywords || condition.includes("salvage") || condition.includes("parts")) {
    category = "repairable"

    if (beginnerRepairs.some((keyword) => title.includes(keyword))) {
      repairLevel = "beginner"
      repairEstimate = vehicleType === "parts" ? price * 0.1 : Math.min(price * 0.15, 1000)
      reason = "Basic maintenance or simple repairs needed"
      estimatedResaleValue = price * (vehicleType === "parts" ? 3.0 : 1.8)
    } else if (intermediateRepairs.some((keyword) => title.includes(keyword))) {
      repairLevel = "intermediate"
      repairEstimate = vehicleType === "parts" ? price * 0.2 : Math.min(price * 0.3, 3000)
      reason = "Moderate mechanical work required - good for experienced DIYers"
      estimatedResaleValue = price * (vehicleType === "parts" ? 2.5 : 1.6)
    } else {
      repairLevel = "expert"
      repairEstimate = vehicleType === "parts" ? price * 0.3 : Math.min(price * 0.5, 8000)
      reason = "Major repairs needed - requires professional skills and equipment"
      estimatedResaleValue = price * (vehicleType === "parts" ? 2.0 : 1.4)
    }

    // Special handling for salvage vehicles
    if (title.includes("salvage") || condition.includes("salvage")) {
      repairLevel = "expert"
      repairEstimate = Math.min(price * 0.6, 10000)
      reason = "Salvage title - extensive repairs needed, check local laws"
      estimatedResaleValue = price * 1.3 // Lower margin due to title issues
    }
  } else {
    // Flippable vehicles
    if (vehicleType === "parts") {
      reason = "Automotive part ready for resale"
      estimatedResaleValue = price * 2.0
    } else if (price < 5000) {
      reason = "Affordable vehicle with flip potential"
      estimatedResaleValue = price * 1.4
    } else if (price < 15000) {
      reason = "Mid-range vehicle - research market value carefully"
      estimatedResaleValue = price * 1.2
    } else {
      reason = "High-value vehicle - requires significant capital and market knowledge"
      estimatedResaleValue = price * 1.15
    }
  }

  // Calculate realistic profit using the profit calculator
  const categoryFees = getCategoryFees(product.title)
  const profitBreakdown = calculateRealProfit(price, estimatedResaleValue, repairEstimate || 0, categoryFees)

  return {
    id: `${Date.now()}-${Math.random()}`,
    title: product.title,
    image: product.thumbnail || "/placeholder.svg?height=200&width=200&text=No+Image",
    price,
    estimatedResaleValue,
    profitMargin: profitBreakdown.profitMargin,
    link: product.link,
    reason,
    category,
    repairLevel,
    repairEstimate,
    condition: product.condition,
    vehicleType,
    year,
    profitBreakdown,
  }
}
