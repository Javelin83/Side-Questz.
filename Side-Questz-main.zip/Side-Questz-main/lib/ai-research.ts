import { createGroq } from "@ai-sdk/groq"
import { generateText } from "ai"

export interface ProductResearch {
  marketValue: number
  demandLevel: "high" | "medium" | "low"
  seasonality: string
  competitorAnalysis: string
  profitPotential: "excellent" | "good" | "fair" | "poor"
  recommendations: string[]
  confidence: number
  source: "ai" | "fallback"
  originalSellingPrice?: number
  aiOverview?: string
}

// Fallback analysis when AI is not available
function getFallbackAnalysis(title: string, condition: string, currentPrice: number): ProductResearch {
  const titleLower = title.toLowerCase()

  // Basic market value estimation
  let marketValue = currentPrice * 1.5
  let demandLevel: "high" | "medium" | "low" = "medium"
  let profitPotential: "excellent" | "good" | "fair" | "poor" = "fair"

  // High-demand keywords
  const highDemandItems = ["iphone", "macbook", "nintendo", "playstation", "xbox", "apple", "samsung", "sony"]
  const lowDemandItems = ["old", "vintage", "rare", "collectible"]

  if (highDemandItems.some((item) => titleLower.includes(item))) {
    demandLevel = "high"
    marketValue = currentPrice * 1.8
    profitPotential = "good"
  } else if (lowDemandItems.some((item) => titleLower.includes(item))) {
    demandLevel = "low"
    marketValue = currentPrice * 1.3
    profitPotential = "fair"
  }

  // Condition adjustments
  if (condition.includes("new") || condition.includes("excellent")) {
    marketValue *= 1.2
    profitPotential = profitPotential === "good" ? "excellent" : "good"
  } else if (condition.includes("poor") || condition.includes("damaged")) {
    marketValue *= 0.8
    profitPotential = "poor"
  }

  // Price-based profit potential
  if (currentPrice < 50) {
    profitPotential = "good"
  } else if (currentPrice > 500) {
    profitPotential = "fair"
  }

  return {
    marketValue: Math.round(marketValue),
    demandLevel,
    seasonality: "No specific seasonal trends identified",
    competitorAnalysis: "Basic analysis suggests moderate competition in this category",
    profitPotential,
    recommendations: [
      "Research completed listings for similar items",
      "Check current market prices on multiple platforms",
      "Consider timing of sale for optimal pricing",
      "Factor in eBay fees and shipping costs",
    ],
    confidence: 65,
    source: "fallback",
  }
}

function extractJSON(text: string): any {
  // Remove markdown code blocks
  let cleaned = text.replace(/```json\s*/g, "").replace(/```\s*/g, "")

  // Try to find JSON object in the text
  const jsonMatch = cleaned.match(/\{[\s\S]*\}/)
  if (jsonMatch) {
    cleaned = jsonMatch[0]
  }

  // Remove any text before the first { and after the last }
  const firstBrace = cleaned.indexOf("{")
  const lastBrace = cleaned.lastIndexOf("}")
  if (firstBrace !== -1 && lastBrace !== -1) {
    cleaned = cleaned.substring(firstBrace, lastBrace + 1)
  }

  return JSON.parse(cleaned)
}

async function callGeminiDirectly(apiKey: string, prompt: string): Promise<string> {
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: prompt,
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.1,
          maxOutputTokens: 2048,
        },
      }),
    },
  )

  if (!response.ok) {
    const errorText = await response.text()
    throw new Error(`Gemini API error: ${response.status} - ${errorText}`)
  }

  const data = await response.json()

  if (!data.candidates || !data.candidates[0] || !data.candidates[0].content) {
    throw new Error("Invalid response structure from Gemini API")
  }

  return data.candidates[0].content.parts[0].text
}

export async function researchProductValue(
  title: string,
  condition: string,
  currentPrice: number,
  originalSellingPrice?: number,
  apiKey?: string,
  provider: "groq" | "gemini" = "gemini",
): Promise<ProductResearch> {
  try {
    const trimmedApiKey = apiKey?.trim()

    if (!trimmedApiKey) {
      throw new Error("No API key available")
    }

    const promptText = `Analyze this eBay product for flipping potential and respond with ONLY a valid JSON object (no markdown, no extra text):

Product: ${title}
Condition: ${condition}
Current Price: $${currentPrice}
${originalSellingPrice ? `Original Estimated Selling Price: $${originalSellingPrice}` : ""}

Return a JSON object with this exact structure:
{
  "marketValue": <number>,
  "demandLevel": "<high|medium|low>",
  "seasonality": "<string>",
  "competitorAnalysis": "<string>",
  "profitPotential": "<excellent|good|fair|poor>",
  "recommendations": ["<string>", "<string>", ...],
  "confidence": <number 0-100>,
  "aiOverview": "<2-3 sentence overview>"
}

Respond with ONLY the JSON object, nothing else.`

    let text: string
    try {
      if (provider === "gemini") {
        text = await callGeminiDirectly(trimmedApiKey, promptText)
      } else {
        const groqInstance = createGroq({
          apiKey: trimmedApiKey,
        })
        const model = groqInstance("llama-3.3-70b-versatile")
        const result = await generateText({
          model,
          prompt: promptText,
          temperature: 0.1,
        })
        text = result.text
      }
    } catch (genError: any) {
      throw new Error(`AI API call failed: ${genError?.message || "Unknown error"}`)
    }

    let parsed: any
    try {
      parsed = extractJSON(text)
    } catch (parseError: any) {
      throw new Error(`Failed to parse AI response as JSON: ${parseError?.message}`)
    }

    // Validate required fields
    if (!parsed.marketValue || !parsed.demandLevel || !parsed.profitPotential) {
      throw new Error("Missing required fields in AI response")
    }

    return {
      marketValue: parsed.marketValue,
      demandLevel: parsed.demandLevel,
      seasonality: parsed.seasonality || "No specific seasonal trends identified",
      competitorAnalysis: parsed.competitorAnalysis || "Analysis not available",
      profitPotential: parsed.profitPotential,
      recommendations: Array.isArray(parsed.recommendations) ? parsed.recommendations : [],
      confidence: parsed.confidence || 70,
      source: "ai",
      originalSellingPrice,
      aiOverview: parsed.aiOverview || "AI analysis completed successfully",
    }
  } catch (error) {
    console.error("AI research error:", error instanceof Error ? error.message : String(error))

    // Fallback to basic analysis
    const fallback = getFallbackAnalysis(title, condition, currentPrice)
    return {
      ...fallback,
      originalSellingPrice,
      aiOverview:
        "Basic analysis suggests this product has moderate flipping potential. Consider researching similar listings for more accurate pricing.",
    }
  }
}

export async function getChatbotResponse(
  message: string,
  context?: string,
  apiKey?: string,
  provider: "groq" | "gemini" = "gemini", // Default to Gemini
): Promise<string> {
  try {
    const trimmedApiKey = apiKey?.trim()

    if (!trimmedApiKey) {
      throw new Error("No API key available")
    }

    const systemPrompt = `You are an expert eBay flipping assistant for Side Questz. Help users with:
- Product analysis and valuation
- Flipping strategies and tips
- Market research guidance
- Profit calculations
- Risk assessment
- Selling optimization

Be concise, practical, and focus on actionable advice.
${context ? `\n\nContext: ${context}` : ""}`

    const fullPrompt = `${systemPrompt}\n\nUser: ${message}\n\nAssistant:`

    let text: string
    if (provider === "gemini") {
      text = await callGeminiDirectly(trimmedApiKey, fullPrompt)
    } else {
      const groqInstance = createGroq({
        apiKey: trimmedApiKey,
      })
      const model = groqInstance("llama-3.3-70b-versatile")
      const result = await generateText({
        model,
        system: systemPrompt,
        prompt: message,
        temperature: 0.7,
        maxTokens: 300,
      })
      text = result.text
    }

    return text
  } catch (error) {
    console.error("Chatbot error:", error)
    return getFallbackChatResponse(message)
  }
}

function getFallbackChatResponse(message: string): string {
  const messageLower = message.toLowerCase()

  if (messageLower.includes("profit") || messageLower.includes("margin")) {
    return "To calculate profit: (Selling Price - Total Cost) / Total Cost × 100 = Profit Margin %. Remember to factor in eBay fees (~10-13%), shipping costs, and your time investment."
  }

  if (messageLower.includes("research") || messageLower.includes("value")) {
    return "For product research: 1) Check completed listings on eBay, 2) Look at current active listings, 3) Consider seasonality, 4) Factor in condition differences, 5) Account for market trends."
  }

  if (messageLower.includes("repair") || messageLower.includes("fix")) {
    return "For repair flips: 1) Accurately estimate repair costs, 2) Consider your skill level, 3) Factor in time investment, 4) Research parts availability, 5) Ensure final value justifies the work."
  }

  if (messageLower.includes("risk") || messageLower.includes("safe")) {
    return "Minimize flipping risks by: 1) Starting with low-cost items, 2) Sticking to categories you know, 3) Researching thoroughly, 4) Having an exit strategy, 5) Diversifying your inventory."
  }

  if (messageLower.includes("category") || messageLower.includes("what to flip")) {
    return "Good beginner categories: Electronics (phones, tablets), Video games, Books, Clothing/shoes, Small appliances. Avoid: Heavy items, fragile antiques, items requiring expertise you don't have."
  }

  return "I'm currently running in basic mode. For detailed flipping advice, consider: researching completed listings, calculating all costs including fees, starting with familiar product categories, and always factoring in your time investment."
}
