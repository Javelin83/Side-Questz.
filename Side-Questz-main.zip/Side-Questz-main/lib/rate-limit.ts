import { createServerClient } from "@supabase/ssr"
import { cookies } from "next/headers"

const DAILY_LIMIT = 50

export async function checkRateLimit(
  ipAddress: string,
): Promise<{ allowed: boolean; remaining: number; resetAt: Date }> {
  const cookieStore = await cookies()

  const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false,
    },
    cookies: {
      getAll() {
        return cookieStore.getAll()
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
      },
    },
  })

  const today = new Date().toISOString().split("T")[0]

  try {
    const { data: existingUsage, error: fetchError } = await supabase
      .from("usage_tracking")
      .select("*")
      .eq("ip_address", ipAddress)
      .eq("usage_date", today)
      .maybeSingle()

    if (fetchError) {
      console.error("Error fetching usage:", fetchError)
      // On error, allow the request but log it
      return { allowed: true, remaining: DAILY_LIMIT, resetAt: getResetTime() }
    }

    if (existingUsage) {
      // Check if limit exceeded
      if (existingUsage.usage_count >= DAILY_LIMIT) {
        return {
          allowed: false,
          remaining: 0,
          resetAt: getResetTime(),
        }
      }

      // Increment usage count
      const { error: updateError } = await supabase
        .from("usage_tracking")
        .update({
          usage_count: existingUsage.usage_count + 1,
          updated_at: new Date().toISOString(),
        })
        .eq("id", existingUsage.id)

      if (updateError) {
        console.error("Error updating usage:", updateError)
      }

      return {
        allowed: true,
        remaining: DAILY_LIMIT - existingUsage.usage_count - 1,
        resetAt: getResetTime(),
      }
    } else {
      // Create new usage record
      const { error: insertError } = await supabase.from("usage_tracking").insert({
        user_id: null,
        ip_address: ipAddress,
        usage_date: today,
        usage_count: 1,
      })

      if (insertError) {
        console.error("Error creating usage record:", insertError)
      }

      return {
        allowed: true,
        remaining: DAILY_LIMIT - 1,
        resetAt: getResetTime(),
      }
    }
  } catch (error) {
    console.error("Rate limit check error:", error)
    // On error, allow the request
    return { allowed: true, remaining: DAILY_LIMIT, resetAt: getResetTime() }
  }
}

function getResetTime(): Date {
  const tomorrow = new Date()
  tomorrow.setDate(tomorrow.getDate() + 1)
  tomorrow.setHours(0, 0, 0, 0)
  return tomorrow
}

export async function getRemainingUses(ipAddress: string): Promise<number> {
  const cookieStore = await cookies()

  const supabase = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
      detectSessionInUrl: false,
    },
    cookies: {
      getAll() {
        return cookieStore.getAll()
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value, options }) => cookieStore.set(name, value, options))
      },
    },
  })

  const today = new Date().toISOString().split("T")[0]

  try {
    const { data: usage } = await supabase
      .from("usage_tracking")
      .select("usage_count")
      .eq("ip_address", ipAddress)
      .eq("usage_date", today)
      .maybeSingle()

    if (!usage) return DAILY_LIMIT

    return Math.max(0, DAILY_LIMIT - usage.usage_count)
  } catch (error) {
    return DAILY_LIMIT
  }
}
