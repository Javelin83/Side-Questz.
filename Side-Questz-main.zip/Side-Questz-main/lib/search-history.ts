export interface SearchHistoryItem {
  id: string
  query: string
  search_engine: string
  created_at: string
}

const SEARCH_HISTORY_KEY = "side-questz-search-history"

export function saveSearchToHistory(query: string, searchEngine: string): SearchHistoryItem | null {
  try {
    const trimmedQuery = query.trim()
    if (!trimmedQuery) return null

    // Get existing history
    const existingHistory = getSearchHistory()

    // Check if this exact query already exists to avoid duplicates
    const existingIndex = existingHistory.findIndex(
      (item) => item.query.toLowerCase() === trimmedQuery.toLowerCase() && item.search_engine === searchEngine,
    )

    // Create new search item
    const newItem: SearchHistoryItem = {
      id: Date.now().toString(),
      query: trimmedQuery,
      search_engine: searchEngine,
      created_at: new Date().toISOString(),
    }

    let updatedHistory: SearchHistoryItem[]

    if (existingIndex >= 0) {
      // Move existing item to top
      updatedHistory = [newItem, ...existingHistory.filter((_, index) => index !== existingIndex)]
    } else {
      // Add new item to top
      updatedHistory = [newItem, ...existingHistory]
    }

    // Keep only the most recent 50 searches
    updatedHistory = updatedHistory.slice(0, 50)

    // Save to localStorage
    localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(updatedHistory))

    return newItem
  } catch (error) {
    console.error("Error saving search history to localStorage:", error)
    return null
  }
}

export function getSearchHistory(limit = 10): SearchHistoryItem[] {
  try {
    const stored = localStorage.getItem(SEARCH_HISTORY_KEY)
    if (!stored) return []

    const history: SearchHistoryItem[] = JSON.parse(stored)
    return history.slice(0, limit)
  } catch (error) {
    console.error("Error reading search history from localStorage:", error)
    return []
  }
}

export function clearSearchHistory(): boolean {
  try {
    localStorage.removeItem(SEARCH_HISTORY_KEY)
    return true
  } catch (error) {
    console.error("Error clearing search history from localStorage:", error)
    return false
  }
}
