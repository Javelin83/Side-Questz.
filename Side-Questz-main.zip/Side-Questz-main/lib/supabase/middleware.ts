import { createServerClient } from "@supabase/ssr"
import { NextResponse, type NextRequest } from "next/server"

export async function updateSession(request: NextRequest) {
  let supabaseResponse = NextResponse.next({
    request,
  })

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
        detectSessionInUrl: false,
      },
      cookies: {
        getAll() {
          return request.cookies.getAll()
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value))
          supabaseResponse = NextResponse.next({
            request,
          })
          cookiesToSet.forEach(({ name, value, options }) => supabaseResponse.cookies.set(name, value, options))
        },
      },
    },
  )

  try {
    const { data, error } = await supabase.auth.getUser()

    if (error) {
      const errorMessage = error.message?.toLowerCase() || ""
      const isTokenError =
        errorMessage.includes("refresh") ||
        errorMessage.includes("token") ||
        errorMessage.includes("jwt") ||
        error.status === 400 ||
        error.status === 401

      if (isTokenError) {
        // Token errors are expected - user will be treated as logged out
        // Don't log these as they're part of normal operation
        return supabaseResponse
      }

      // Log other unexpected errors
      console.error("Supabase auth error:", error)
    }
  } catch (error: any) {
    // This prevents token refresh errors from breaking the app
    const errorMessage = error?.message?.toLowerCase() || ""
    const isTokenError =
      errorMessage.includes("refresh") ||
      errorMessage.includes("token") ||
      errorMessage.includes("already used") ||
      errorMessage.includes("not found")

    if (!isTokenError) {
      // Only log non-token errors
      console.error("Middleware error:", error)
    }
  }

  // IMPORTANT: You *must* return the supabaseResponse object as it is.
  return supabaseResponse
}
