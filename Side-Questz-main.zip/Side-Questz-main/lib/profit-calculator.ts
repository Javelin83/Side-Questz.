export interface ProfitBreakdown {
  purchasePrice: number
  repairCosts: number
  ebayFees: number
  paypalFees: number
  shippingCosts: number
  packagingCosts: number
  totalCosts: number
  sellingPrice: number
  netProfit: number
  profitMargin: number
}

export interface FeeStructure {
  ebayFinalValueFee: number // percentage
  ebayInsertionFee: number // flat fee
  paypalFee: number // percentage
  estimatedShipping: number // flat fee
  packagingCosts: number // flat fee
}

export function calculateRealProfit(
  purchasePrice: number,
  estimatedSellingPrice: number,
  repairCosts = 0,
  customFees?: Partial<FeeStructure>,
): ProfitBreakdown {
  // Default fee structure based on eBay's current rates
  const defaultFees: FeeStructure = {
    ebayFinalValueFee: 0.1295, // 12.95% for most categories
    ebayInsertionFee: 0.35, // $0.35 insertion fee
    paypalFee: 0.0349, // 3.49% + $0.49 (simplified to percentage)
    estimatedShipping: 8.5, // Average shipping cost
    packagingCosts: 2.0, // Packaging materials
  }

  const fees = { ...defaultFees, ...customFees }

  // Calculate all costs
  const ebayFees = estimatedSellingPrice * fees.ebayFinalValueFee + fees.ebayInsertionFee
  const paypalFees = estimatedSellingPrice * fees.paypalFee + 0.49 // PayPal fixed fee
  const shippingCosts = fees.estimatedShipping
  const packagingCosts = fees.packagingCosts

  const totalCosts = purchasePrice + repairCosts + ebayFees + paypalFees + shippingCosts + packagingCosts
  const netProfit = estimatedSellingPrice - totalCosts
  const profitMargin = totalCosts > 0 ? (netProfit / totalCosts) * 100 : 0

  return {
    purchasePrice,
    repairCosts,
    ebayFees: Math.round(ebayFees * 100) / 100,
    paypalFees: Math.round(paypalFees * 100) / 100,
    shippingCosts,
    packagingCosts,
    totalCosts: Math.round(totalCosts * 100) / 100,
    sellingPrice: estimatedSellingPrice,
    netProfit: Math.round(netProfit * 100) / 100,
    profitMargin: Math.round(profitMargin * 100) / 100,
  }
}

// Category-specific fee adjustments
export function getCategoryFees(title: string): Partial<FeeStructure> {
  const titleLower = title.toLowerCase()

  // Motors category has different fees
  if (titleLower.includes("car") || titleLower.includes("motorcycle") || titleLower.includes("truck")) {
    return {
      ebayFinalValueFee: 0.1, // 10% for vehicles
      estimatedShipping: 0, // Usually pickup only
      packagingCosts: 0,
    }
  }

  // Electronics often have higher shipping
  if (titleLower.includes("iphone") || titleLower.includes("laptop") || titleLower.includes("computer")) {
    return {
      estimatedShipping: 12.0,
      packagingCosts: 3.0,
    }
  }

  // Heavy items
  if (titleLower.includes("furniture") || titleLower.includes("appliance")) {
    return {
      estimatedShipping: 25.0,
      packagingCosts: 5.0,
    }
  }

  // Small items
  if (titleLower.includes("jewelry") || titleLower.includes("watch") || titleLower.includes("coin")) {
    return {
      estimatedShipping: 4.5,
      packagingCosts: 1.0,
    }
  }

  return {}
}
