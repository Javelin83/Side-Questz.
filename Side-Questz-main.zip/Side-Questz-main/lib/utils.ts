import type { EbayProduct, FlipProduct, RepairLevel } from "./types"
import { calculateRealProfit, getCategoryFees } from "./profit-calculator"

export function cn(...classes: string[]) {
  return classes.filter(Boolean).join(" ")
}

export function optimizeEbayImageUrl(url: string): string {
  if (!url || url.includes("placeholder")) return url

  // eBay image optimization - request higher quality versions
  if (url.includes("ebayimg.com")) {
    // Remove size restrictions and request high quality
    return url.replace(/s-l\d+/g, "s-l1600").replace(/\$_\d+\.JPG/g, "$_57.JPG")
  }

  return url
}

export function getImagePlaceholder(width = 400, height = 400): string {
  return `data:image/svg+xml;base64,${btoa(`
    <svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
      <rect width="100%" height="100%" fill="#f3f4f6"/>
      <text x="50%" y="50%" font-family="Arial, sans-serif" font-size="16" fill="#9ca3af" text-anchor="middle" dy=".3em">
        Loading...
      </text>
    </svg>
  `)}`
}

export function analyzeProduct(product: EbayProduct): FlipProduct {
  const title = product.title.toLowerCase()
  const condition = product.condition?.toLowerCase() || ""
  const price = product.price?.extracted || 0

  // Expanded keywords for better detection
  const flippableKeywords = ["new", "sealed", "mint", "excellent", "like new", "unused", "perfect", "pristine"]

  const repairableKeywords = [
    // Direct repair indicators
    "broken",
    "damaged",
    "cracked",
    "repair",
    "not working",
    "faulty",
    "defective",
    "parts",
    "spares",
    "fix",
    "restore",
    "project",
    "untested",
    "as-is",
    // Condition indicators
    "poor",
    "fair",
    "needs work",
    "for parts",
    "salvage",
    "scrap",
    // Specific damage types
    "water damage",
    "screen crack",
    "battery",
    "dead",
    "won't turn on",
    "missing parts",
    "incomplete",
    "no power",
    "doesn't work",
  ]

  const beginnerRepairs = [
    "battery",
    "charger",
    "cable",
    "remote",
    "cleaning",
    "dust",
    "dirty",
    "missing cable",
    "no charger",
    "needs battery",
    "dead battery",
  ]

  const intermediateRepairs = [
    "screen",
    "display",
    "lcd",
    "button",
    "speaker",
    "camera",
    "lens",
    "keyboard",
    "trackpad",
    "mouse",
    "headphone jack",
    "charging port",
  ]

  const expertRepairs = [
    "motherboard",
    "logic board",
    "water damage",
    "circuit",
    "pcb",
    "won't boot",
    "no display",
    "gpu",
    "cpu",
    "hard drive",
    "ssd",
  ]

  let category: "flippable" | "repairable" = "flippable"
  let repairLevel: RepairLevel | undefined
  let repairEstimate: number | undefined
  let reason = ""
  let estimatedResaleValue = price * 1.5

  // Check condition field first
  const conditionIndicatesRepair =
    condition.includes("parts") ||
    condition.includes("repair") ||
    condition.includes("poor") ||
    condition.includes("fair")

  // More aggressive repairable detection
  const hasRepairKeywords = repairableKeywords.some((keyword) => title.includes(keyword) || condition.includes(keyword))

  // Also check for "as-is" sales and low prices relative to typical market value
  const isAsIs = title.includes("as-is") || title.includes("as is")
  const isPotentiallyBroken = price < 100 && (title.includes("untested") || isAsIs)

  if (hasRepairKeywords || conditionIndicatesRepair || isPotentiallyBroken) {
    category = "repairable"

    // Determine repair level
    if (beginnerRepairs.some((keyword) => title.includes(keyword) || condition.includes(keyword))) {
      repairLevel = "beginner"
      repairEstimate = Math.min(price * 0.15, 25)
      reason = "Simple repair - likely needs replacement part, cleaning, or basic maintenance"
      estimatedResaleValue = price * 2.2
    } else if (intermediateRepairs.some((keyword) => title.includes(keyword) || condition.includes(keyword))) {
      repairLevel = "intermediate"
      repairEstimate = Math.min(price * 0.3, 75)
      reason = "Moderate repair - requires technical skills and possibly specialized tools"
      estimatedResaleValue = price * 2.0
    } else {
      repairLevel = "expert"
      repairEstimate = Math.min(price * 0.5, 150)
      reason = "Complex repair - needs advanced technical skills and diagnostic equipment"
      estimatedResaleValue = price * 1.8
    }

    // Special handling for very low-priced items (likely broken)
    if (price < 50 && !repairLevel) {
      repairLevel = "intermediate"
      repairEstimate = Math.min(price * 0.4, 50)
      reason = "Low-priced item likely needs repair - good project opportunity"
      estimatedResaleValue = price * 2.5
    }
  } else if (flippableKeywords.some((keyword) => title.includes(keyword) || condition.includes(keyword))) {
    reason = "Good condition item ready for immediate resale"
    estimatedResaleValue = price * 1.3
  } else {
    // Default categorization - be more aggressive about repair classification
    if (price < 30) {
      // Very cheap items are often broken or need work
      category = "repairable"
      repairLevel = "beginner"
      repairEstimate = Math.min(price * 0.2, 20)
      reason = "Very low price suggests item may need basic repair or refurbishment"
      estimatedResaleValue = price * 3.0
    } else if (price < 100 && title.includes("untested")) {
      category = "repairable"
      repairLevel = "intermediate"
      repairEstimate = Math.min(price * 0.3, 40)
      reason = "Untested item - likely needs diagnosis and potential repair"
      estimatedResaleValue = price * 2.2
    } else {
      // Regular flippable items
      if (price < 50) {
        reason = "Low-risk flip opportunity with decent margin potential"
      } else if (price < 200) {
        reason = "Mid-range item with good profit potential"
      } else {
        reason = "High-value item - research market demand carefully"
        estimatedResaleValue = price * 1.2
      }
    }
  }

  // Calculate realistic profit using the profit calculator
  const categoryFees = getCategoryFees(product.title)
  const profitBreakdown = calculateRealProfit(price, estimatedResaleValue, repairEstimate || 0, categoryFees)

  return {
    id: `${Date.now()}-${Math.random()}`,
    title: product.title,
    image: optimizeEbayImageUrl(product.thumbnail) || "/placeholder.svg?height=200&width=200&text=No+Image",
    price,
    estimatedResaleValue,
    profitMargin: profitBreakdown.profitMargin,
    link: product.link,
    reason,
    category,
    repairLevel,
    repairEstimate,
    condition: product.condition,
    // Add profit breakdown for detailed display
    profitBreakdown,
  }
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(amount)
}

export function formatPercentage(value: number): string {
  return `${value.toFixed(1)}%`
}
