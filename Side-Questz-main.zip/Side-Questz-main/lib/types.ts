import type { ProfitBreakdown } from "./profit-calculator"
import type { ProductResearch } from "./ai-research" // Import ProductResearch type

export interface EbayProduct {
  title: string
  link: string
  price: {
    raw: number
    extracted: number
  }
  thumbnail: string
  condition?: string
  shipping?: string
  location?: string
}

export interface FlipProduct {
  id: string
  title: string
  image: string
  price: number
  estimatedResaleValue: number
  profitMargin: number
  link: string
  reason: string
  category: "flippable" | "repairable"
  repairLevel?: "beginner" | "intermediate" | "expert"
  repairEstimate?: number
  condition?: string
  vehicleType?: "car" | "motorcycle" | "truck" | "parts" | "other"
  mileage?: string
  year?: string
  make?: string
  model?: string
  profitBreakdown?: ProfitBreakdown
  aiResearch?: ProductResearch // Add aiResearch field to store AI analysis
}

export type RepairLevel = "beginner" | "intermediate" | "expert"

export type SearchEngine = "ebay" | "ebay_motors"
