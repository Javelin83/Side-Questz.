import { createClient } from "@/lib/supabase/server"

export interface AppSettings {
  groq_api_key?: string
  openai_api_key?: string
  serpapi_key?: string
}

export async function getAppSettings(): Promise<AppSettings> {
  try {
    const supabase = await createClient()

    const { data, error } = await supabase.from("app_settings").select("key, value")

    if (error) {
      // Table doesn't exist yet or other error - return empty settings
      // The app will fall back to environment variables
      console.log("App settings table not found or error occurred, using environment variables as fallback")
      return {}
    }

    const settings: AppSettings = {}
    data?.forEach((row) => {
      if (row.value) {
        settings[row.key as keyof AppSettings] = row.value
      }
    })

    return settings
  } catch (error) {
    console.log("Error accessing app settings, using environment variables as fallback")
    return {}
  }
}

export async function updateAppSetting(key: string, value: string): Promise<boolean> {
  const supabase = await createClient()

  const { error } = await supabase.from("app_settings").upsert({ key, value, updated_at: new Date().toISOString() })

  if (error) {
    console.error("Error updating app setting:", error)
    return false
  }

  return true
}

export async function getApiKey(keyName: keyof AppSettings): Promise<string | null> {
  const settings = await getAppSettings()
  const value = settings[keyName]
  return value ? value.trim() : null
}
