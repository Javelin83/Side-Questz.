-- Remove foreign key constraint that's causing RLS policy violations
ALTER TABLE search_history DROP CONSTRAINT IF EXISTS search_history_user_id_fkey;

-- Add a comment to document that user_id references auth.users (managed by Supabase Auth)
COMMENT ON COLUMN search_history.user_id IS 'References auth.users.id (Supabase Auth managed table)';
