-- Add Gemini API key to app_settings table
INSERT INTO app_settings (key, value) VALUES
  ('gemini_api_key', '')
ON CONFLICT (key) DO NOTHING;
