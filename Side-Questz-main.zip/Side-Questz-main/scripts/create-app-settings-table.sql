-- Create app_settings table to securely store global API keys
-- Changed from user_settings to app_settings for global configuration
CREATE TABLE IF NOT EXISTS app_settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;

-- Policy: Only authenticated users can read settings
-- Simplified RLS - any authenticated user can read (for app functionality)
CREATE POLICY "Authenticated users can read settings"
  ON app_settings
  FOR SELECT
  TO authenticated
  USING (true);

-- Policy: Only service role can modify settings (admin only)
-- Only service role can insert/update/delete for security
CREATE POLICY "Service role can manage settings"
  ON app_settings
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Insert default keys (empty values - to be filled by admin)
INSERT INTO app_settings (key, value) VALUES
  ('groq_api_key', ''),
  ('openai_api_key', ''),
  ('serpapi_key', '')
ON CONFLICT (key) DO NOTHING;

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_app_settings_key ON app_settings(key);
