-- Create usage_tracking table to track daily API usage per user/IP
CREATE TABLE IF NOT EXISTS usage_tracking (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  ip_address TEXT,
  usage_date DATE NOT NULL DEFAULT CURRENT_DATE,
  usage_count INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(user_id, usage_date),
  UNIQUE(ip_address, usage_date)
);

-- Enable Row Level Security
ALTER TABLE usage_tracking ENABLE ROW LEVEL SECURITY;

-- Allow anonymous users to read and insert their own usage records
-- Policy: Anyone can read usage data
CREATE POLICY "Anyone can read usage"
  ON usage_tracking
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Policy: Anyone can insert usage records
CREATE POLICY "Anyone can insert usage"
  ON usage_tracking
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (true);

-- Policy: Anyone can update usage records
CREATE POLICY "Anyone can update usage"
  ON usage_tracking
  FOR UPDATE
  TO anon, authenticated
  USING (true)
  WITH CHECK (true);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_usage_tracking_user_date ON usage_tracking(user_id, usage_date);
CREATE INDEX IF NOT EXISTS idx_usage_tracking_ip_date ON usage_tracking(ip_address, usage_date);

-- Function to clean up old usage records (optional, keeps last 30 days)
CREATE OR REPLACE FUNCTION cleanup_old_usage()
RETURNS void AS $$
BEGIN
  DELETE FROM usage_tracking WHERE usage_date < CURRENT_DATE - INTERVAL '30 days';
END;
$$ LANGUAGE plpgsql;
