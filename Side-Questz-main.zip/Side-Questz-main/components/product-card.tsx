import Image from "next/image"
import Link from "next/link"
import { ExternalLink, TrendingUp } from "lucide-react"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import type { FlipProduct } from "@/lib/types"
import { formatCurrency, formatPercentage } from "@/lib/utils"
import { Car, WrenchIcon, Calendar } from "lucide-react"

interface ProductCardProps {
  product: FlipProduct
}

export default function ProductCard({ product }: ProductCardProps) {
  const profitColor =
    product.profitMargin > 50 ? "text-green-600" : product.profitMargin > 25 ? "text-yellow-600" : "text-red-600"

  const repairLevelColors = {
    beginner: "bg-green-100 text-green-800",
    intermediate: "bg-yellow-100 text-yellow-800",
    expert: "bg-red-100 text-red-800",
  }

  const vehicleTypeColors = {
    car: "bg-blue-100 text-blue-800",
    motorcycle: "bg-purple-100 text-purple-800",
    truck: "bg-gray-100 text-gray-800",
    parts: "bg-orange-100 text-orange-800",
    other: "bg-gray-100 text-gray-800",
  }

  const totalCost = product.price + (product.repairEstimate || 0)
  const netProfit = product.estimatedResaleValue - totalCost

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="p-4">
        <div className="relative aspect-square mb-3 bg-gray-100 rounded-md overflow-hidden">
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.title}
            fill
            className="object-cover rounded-md transition-opacity duration-300"
            sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            quality={85}
            priority={false}
            placeholder="blur"
            blurDataURL="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDAAYEBQYFBAYGBQYHBwYIChAKCgkJChQODwwQFxQYGBcUFhYaHSUfGhsjHBYWICwgIyYnKSopGR8tMC0oMCUoKSj/2wBDAQcHBwoIChMKChMoGhYaKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCj/wAARCAABAAEDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAv/xAAhEAACAQMDBQAAAAAAAAAAAAABAgMABAUGIWGRkqGx0f/EABUBAQEAAAAAAAAAAAAAAAAAAAMF/8QAGhEAAgIDAAAAAAAAAAAAAAAAAAECEgMRkf/aAAwDAQACEQMRAD8AltJagyeH0AthI5xdrLcNM91BF5pX2HaH9bcfaSXWGaRmknyJckliyjqTzSlT54b6bk+h0R//2Q=="
            onError={(e) => {
              const target = e.target as HTMLImageElement
              target.src = "/placeholder.svg"
            }}
          />
        </div>
        <h3 className="font-semibold text-sm line-clamp-2 min-h-[2.5rem]">{product.title}</h3>
      </CardHeader>

      <CardContent className="p-4 pt-0 flex-1">
        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-lg font-bold">{formatCurrency(product.price)}</span>
            <div className="flex items-center gap-1">
              <TrendingUp className="w-4 h-4 text-green-600" />
              <span className={`font-semibold ${profitColor}`}>{formatPercentage(product.profitMargin)}</span>
            </div>
          </div>

          {product.year && (
            <div className="flex items-center gap-2 text-sm text-gray-600">
              <Calendar className="w-4 h-4" />
              <span>{product.year}</span>
            </div>
          )}

          {product.repairEstimate && (
            <div className="text-sm bg-orange-50 border border-orange-200 rounded-md p-2">
              <div className="flex justify-between">
                <span className="text-orange-700">Repair Est.:</span>
                <span className="font-semibold text-orange-800">{formatCurrency(product.repairEstimate)}</span>
              </div>
              <div className="flex justify-between text-xs text-orange-600 mt-1">
                <span>Total Cost:</span>
                <span>{formatCurrency(totalCost)}</span>
              </div>
            </div>
          )}

          <div className="text-sm text-gray-600">
            <div>
              Est. Resale: <span className="font-semibold">{formatCurrency(product.estimatedResaleValue)}</span>
            </div>
            <div>
              Net Profit:{" "}
              <span className={`font-semibold ${netProfit > 0 ? "text-green-600" : "text-red-600"}`}>
                {formatCurrency(netProfit)}
              </span>
            </div>
          </div>

          <div className="flex gap-2 flex-wrap">
            <Badge variant={product.category === "flippable" ? "default" : "secondary"}>
              {product.category === "flippable" ? "Ready to Flip" : "Needs Repair"}
            </Badge>

            {product.vehicleType && (
              <Badge className={vehicleTypeColors[product.vehicleType]}>
                <Car className="w-3 h-3 mr-1" />
                {product.vehicleType}
              </Badge>
            )}

            {product.repairLevel && (
              <Badge className={repairLevelColors[product.repairLevel]}>
                <WrenchIcon className="w-3 h-3 mr-1" />
                {product.repairLevel}
              </Badge>
            )}
          </div>

          <p className="text-xs text-gray-500 line-clamp-2">{product.reason}</p>
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0">
        <Button asChild className="w-full" size="sm">
          <Link href={product.link} target="_blank" rel="noopener noreferrer">
            View on eBay
            <ExternalLink className="w-4 h-4 ml-2" />
          </Link>
        </Button>
      </CardFooter>
    </Card>
  )
}
