"use client"

import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { useEffect, useState } from "react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { LogOut, Search, Settings, Zap } from "lucide-react"
import FlipFinder from "@/components/flip-finder"
import Link from "next/link"

interface User {
  id: string
  email: string
}

export default function AppShell() {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)
  const [remainingUses, setRemainingUses] = useState<number | null>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    // Get initial session
    const getSession = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()
      setUser(session?.user ? { id: session.user.id, email: session.user.email || "" } : null)
      setLoading(false)
    }

    getSession()

    // Listen for auth changes
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ? { id: session.user.id, email: session.user.email || "" } : null)
      setLoading(false)
    })

    return () => subscription.unsubscribe()
  }, [supabase.auth])

  useEffect(() => {
    const fetchRemainingUses = async () => {
      try {
        const response = await fetch("/api/usage")
        if (response.ok) {
          const data = await response.json()
          setRemainingUses(data.remaining)
        }
      } catch (error) {
        console.error("Failed to fetch usage:", error)
      }
    }

    fetchRemainingUses()
    // Refresh every 30 seconds
    const interval = setInterval(fetchRemainingUses, 30000)
    return () => clearInterval(interval)
  }, [])

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center gradient-mesh">
        <div className="text-center glass-morphism p-8 rounded-2xl">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-white font-semibold">Loading your dashboard...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return null // This will be handled by the protected route logic
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 gradient-mesh"></div>

      {/* Floating glass elements */}
      <div className="absolute top-10 right-20 w-24 h-24 glass-morphism rounded-full floating-animation opacity-20"></div>
      <div className="absolute bottom-20 left-10 w-32 h-32 glass-morphism rounded-full floating-animation-delayed opacity-15"></div>

      <header className="relative z-10 border-b border-white/20 bg-white/10 backdrop-blur-md sticky top-0">
        <div className="container mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="h-12 w-12 glass-morphism rounded-xl flex items-center justify-center">
                <Search className="h-7 w-7 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-black text-white">Side Questz</h1>
                <span className="text-xs text-white/70 font-medium">AI-Powered Flip Finder</span>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {remainingUses !== null && (
                <div className="glass-morphism px-4 py-2 rounded-lg flex items-center gap-2">
                  <Zap
                    className={`h-4 w-4 ${remainingUses > 10 ? "text-green-400" : remainingUses > 5 ? "text-yellow-400" : "text-red-400"}`}
                  />
                  <div className="text-white">
                    <p className="text-xs font-medium leading-none">AI Research</p>
                    <p className="text-sm font-bold">
                      {remainingUses}/50 <span className="text-xs font-normal text-white/70">today</span>
                    </p>
                  </div>
                </div>
              )}

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    className="relative h-12 w-12 rounded-full glass-morphism hover:bg-white/30 transition-all duration-200 hover:scale-105"
                  >
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-white/20 text-white font-bold text-lg backdrop-blur-sm">
                        {user.email.charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 glass-morphism border-white/20" align="end" forceMount>
                  <div className="flex items-center justify-start gap-2 p-3 border-b border-white/10">
                    <div className="flex flex-col space-y-1 leading-none">
                      <p className="text-xs text-white/60 font-medium">Signed in as</p>
                      <p className="w-[200px] truncate text-sm text-white font-semibold">{user.email}</p>
                    </div>
                  </div>
                  <Link href="/settings">
                    <DropdownMenuItem className="cursor-pointer text-white hover:bg-white/20 mt-1">
                      <Settings className="mr-2 h-4 w-4" />
                      <span>Settings</span>
                    </DropdownMenuItem>
                  </Link>
                  <DropdownMenuItem onClick={handleSignOut} className="cursor-pointer text-white hover:bg-white/20">
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Sign out</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </header>

      {/* Main App Content */}
      <main className="relative z-10">
        <FlipFinder />
      </main>
    </div>
  )
}
