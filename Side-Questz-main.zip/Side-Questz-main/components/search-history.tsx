"use client"

import { useState, useEffect } from "react"
import { Clock, X, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { getSearchHistory, clearSearchHistory, type SearchHistoryItem } from "@/lib/search-history"

interface SearchHistoryProps {
  onSelectSearch: (query: string, engine: string) => void
  isVisible: boolean
  onClose: () => void
}

export default function SearchHistory({ onSelectSearch, isVisible, onClose }: SearchHistoryProps) {
  const [history, setHistory] = useState<SearchHistoryItem[]>([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (isVisible) {
      loadHistory()
    }
  }, [isVisible])

  const loadHistory = async () => {
    setLoading(true)
    const historyData = await getSearchHistory(10)
    setHistory(historyData)
    setLoading(false)
  }

  const handleClearHistory = async () => {
    const success = await clearSearchHistory()
    if (success) {
      setHistory([])
    }
  }

  const handleSelectSearch = (item: SearchHistoryItem) => {
    onSelectSearch(item.query, item.search_engine)
    onClose()
  }

  if (!isVisible) return null

  return (
    <div className="absolute top-full left-0 right-0 mt-2 glass-card border-0 bg-white/20 backdrop-blur-md z-50">
      <div className="p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-medium text-slate-700 flex items-center gap-2">
            <Clock className="w-4 h-4" />
            Recent Searches
          </h3>
          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <Button
                onClick={handleClearHistory}
                variant="ghost"
                size="sm"
                className="text-slate-500 hover:text-red-600 p-1"
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            )}
            <Button onClick={onClose} variant="ghost" size="sm" className="text-slate-500 hover:text-slate-700 p-1">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-4">
            <div className="text-sm text-slate-500">Loading history...</div>
          </div>
        ) : history.length === 0 ? (
          <div className="text-center py-4">
            <div className="text-sm text-slate-500">No recent searches</div>
          </div>
        ) : (
          <div className="space-y-1 max-h-60 overflow-y-auto">
            {history.map((item) => (
              <button
                key={item.id}
                onClick={() => handleSelectSearch(item)}
                className="w-full text-left px-3 py-2 rounded-md hover:bg-white/20 transition-colors duration-200 group"
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium text-slate-700 truncate">{item.query}</div>
                    <div className="text-xs text-slate-500 flex items-center gap-2">
                      <span className="capitalize">{item.search_engine.replace("_", " ")}</span>
                      <span>•</span>
                      <span>{new Date(item.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                  <Clock className="w-3 h-3 text-slate-400 opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
