"use client"

import type React from "react"

import { useState, useMemo } from "react"
import { Search, Filter, Loader2, Car, DollarSign, Clock } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import EnhancedProductCard from "./enhanced-product-card"
import Chatbot from "./chatbot"
import SearchHistory from "./search-history"
import type { FlipProduct, RepairLevel, SearchEngine } from "@/lib/types"
import { analyzeProduct } from "@/lib/utils"
import { analyzeAutomotiveProduct } from "@/lib/automotive-utils"
import { saveSearchToHistory } from "@/lib/search-history"

export default function FlipFinder() {
  const [searchQuery, setSearchQuery] = useState("")
  const [products, setProducts] = useState<FlipProduct[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [repairFilter, setRepairFilter] = useState<RepairLevel | "all">("all")
  const [searchEngine, setSearchEngine] = useState<SearchEngine>("ebay")
  const [minProfitMargin, setMinProfitMargin] = useState([0]) // Slider returns array
  const [minProfitAmount, setMinProfitAmount] = useState([0])
  const [showSearchHistory, setShowSearchHistory] = useState(false)

  const searchProducts = async (query: string, engine: SearchEngine = searchEngine) => {
    if (!query.trim()) return

    setLoading(true)
    setError(null)

    try {
      const response = await fetch(`/api/search?q=${encodeURIComponent(query)}&engine=${engine}`)

      if (!response.ok) {
        throw new Error("Failed to fetch search results")
      }

      const data = await response.json()

      if (data.error) {
        throw new Error(data.error)
      }

      const ebayResults = data.organic_results || []
      const analyzedProducts = ebayResults.map((product: any) =>
        engine === "ebay_motors" ? analyzeAutomotiveProduct(product) : analyzeProduct(product),
      )

      setProducts(analyzedProducts)
      await saveSearchToHistory(query, engine)
    } catch (err) {
      setError(err instanceof Error ? err.message : "An error occurred")
      setProducts([])
    } finally {
      setLoading(false)
    }
  }

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    searchProducts(searchQuery, searchEngine)
    setShowSearchHistory(false)
  }

  const handleEngineChange = (engine: SearchEngine) => {
    setSearchEngine(engine)
  }

  const handleSelectFromHistory = (query: string, engine: string) => {
    setSearchQuery(query)
    setSearchEngine(engine as SearchEngine)
    searchProducts(query, engine as SearchEngine)
  }

  // useEffect(() => {
  //   const timer = setTimeout(() => {
  //     if (searchQuery.trim()) {
  //       searchProducts(searchQuery, searchEngine)
  //     }
  //   }, 500)
  //
  //   return () => clearTimeout(timer)
  // }, [searchQuery, searchEngine])

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const netProfit = product.profitBreakdown?.netProfit || 0
      return product.profitMargin >= minProfitMargin[0] && netProfit >= minProfitAmount[0]
    })
  }, [products, minProfitMargin, minProfitAmount])

  const flippableProducts = useMemo(
    () => filteredProducts.filter((p) => p.category === "flippable"),
    [filteredProducts],
  )

  const repairableProducts = useMemo(() => {
    const filtered = filteredProducts.filter((p) => p.category === "repairable")
    if (repairFilter === "all") return filtered
    return filtered.filter((p) => p.repairLevel === repairFilter)
  }, [filteredProducts, repairFilter])

  const motorProducts = useMemo(() => filteredProducts.filter((p) => p.vehicleType), [filteredProducts])
  const flippableMotors = useMemo(() => motorProducts.filter((p) => p.category === "flippable"), [motorProducts])
  const repairableMotors = useMemo(() => {
    const filtered = motorProducts.filter((p) => p.category === "repairable")
    if (repairFilter === "all") return filtered
    return filtered.filter((p) => p.repairLevel === repairFilter)
  }, [motorProducts, repairFilter])

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="container mx-auto px-4 py-8 relative z-10">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-6">
            <p className="text-lg font-open-sans text-white/90">
              Discover profitable products with AI-powered analysis and realistic profit calculations
            </p>
          </div>

          <div className="flex justify-center mb-6">
            <div className="glass-card p-1.5 inline-flex gap-1">
              <button
                onClick={() => handleEngineChange("ebay")}
                className={`px-6 py-2.5 rounded-lg text-sm font-semibold transition-all duration-300 font-open-sans ${
                  searchEngine === "ebay"
                    ? "bg-white/90 text-slate-900 shadow-lg"
                    : "text-white/80 hover:text-white hover:bg-white/10"
                }`}
              >
                eBay General
              </button>
              <button
                onClick={() => handleEngineChange("ebay_motors")}
                className={`px-6 py-2.5 rounded-lg text-sm font-semibold transition-all duration-300 flex items-center gap-2 font-open-sans ${
                  searchEngine === "ebay_motors"
                    ? "bg-white/90 text-slate-900 shadow-lg"
                    : "text-white/80 hover:text-white hover:bg-white/10"
                }`}
              >
                <Car className="w-4 h-4" />
                eBay Motors
              </button>
            </div>
          </div>

          <form onSubmit={handleSearch} className="mb-8">
            <div className="flex gap-3 max-w-3xl mx-auto relative">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-white/60 w-5 h-5" />
                <Input
                  type="text"
                  placeholder={
                    searchEngine === "ebay_motors"
                      ? "Search for vehicles with AI analysis..."
                      : "Search for products with AI analysis..."
                  }
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onFocus={() => setShowSearchHistory(true)}
                  className="pl-12 pr-12 h-14 glass-input border-0 bg-white/20 backdrop-blur-md text-white placeholder:text-white/50 focus:bg-white/30 transition-all duration-300 text-lg"
                />
                <Button
                  type="button"
                  onClick={() => setShowSearchHistory(!showSearchHistory)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 p-2 h-auto bg-transparent hover:bg-white/20 text-white/60 hover:text-white"
                >
                  <Clock className="w-5 h-5" />
                </Button>
                <SearchHistory
                  isVisible={showSearchHistory}
                  onSelectSearch={handleSelectFromHistory}
                  onClose={() => setShowSearchHistory(false)}
                />
              </div>
              <Button
                type="submit"
                disabled={loading}
                className="glass-button px-8 h-14 text-base font-semibold font-open-sans hover:scale-105 transition-transform"
              >
                {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : "Search"}
              </Button>
            </div>
          </form>

          {products.length > 0 && (
            <div className="glass-card mb-8">
              <div className="p-6">
                <h3 className="text-lg font-bold text-white mb-4 flex items-center gap-2">
                  <Filter className="w-5 h-5" />
                  Filter Results
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-3">
                    <Label className="flex items-center gap-2 text-white font-semibold font-open-sans text-base">
                      <DollarSign className="w-5 h-5" />
                      Minimum Profit Margin: {minProfitMargin[0]}%
                    </Label>
                    <Slider
                      value={minProfitMargin}
                      onValueChange={setMinProfitMargin}
                      max={200}
                      step={5}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-white/70 font-medium">
                      <span>0%</span>
                      <span>200%</span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Label className="flex items-center gap-2 text-white font-semibold font-open-sans text-base">
                      <DollarSign className="w-5 h-5" />
                      Minimum Net Profit: ${minProfitAmount[0]}
                    </Label>
                    <Slider
                      value={minProfitAmount}
                      onValueChange={setMinProfitAmount}
                      max={1000}
                      step={10}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-white/70 font-medium">
                      <span>$0</span>
                      <span>$1000+</span>
                    </div>
                  </div>
                </div>

                <div className="mt-6 p-4 bg-white/10 rounded-lg text-center">
                  <p className="text-white font-semibold text-base">
                    Showing {filteredProducts.length} of {products.length} products
                  </p>
                  <p className="text-sm text-emerald-300 mt-1">
                    ✓ Includes all eBay fees, PayPal fees, shipping, and packaging costs
                  </p>
                </div>
              </div>
            </div>
          )}

          {error && (
            <div className="glass-card mb-6 border-red-200/30 bg-red-50/20">
              <div className="p-4">
                <p className="text-red-600 text-center font-open-sans">{error}</p>
              </div>
            </div>
          )}

          {filteredProducts.length > 0 && (
            <div className="w-full">
              <Tabs defaultValue="flippable" className="w-full">
                <TabsList
                  className={`grid w-full ${searchEngine === "ebay_motors" ? "grid-cols-3" : "grid-cols-2"} mb-8 glass-card p-2 h-auto`}
                >
                  <TabsTrigger
                    value="flippable"
                    className="flex items-center gap-2 font-open-sans text-base py-3 data-[state=active]:bg-white/20 data-[state=active]:text-white"
                  >
                    Flippable ({searchEngine === "ebay_motors" ? flippableMotors.length : flippableProducts.length})
                  </TabsTrigger>
                  <TabsTrigger
                    value="repairable"
                    className="flex items-center gap-2 font-open-sans text-base py-3 data-[state=active]:bg-white/20 data-[state=active]:text-white"
                  >
                    Repairable ({searchEngine === "ebay_motors" ? repairableMotors.length : repairableProducts.length})
                  </TabsTrigger>
                  {searchEngine === "ebay_motors" && (
                    <TabsTrigger
                      value="all-motors"
                      className="flex items-center gap-2 font-open-sans text-base py-3 data-[state=active]:bg-white/20 data-[state=active]:text-white"
                    >
                      <Car className="w-4 h-4" />
                      All Motors ({motorProducts.length})
                    </TabsTrigger>
                  )}
                </TabsList>

                <TabsContent value="flippable">
                  {(searchEngine === "ebay_motors" ? flippableMotors : flippableProducts).length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {(searchEngine === "ebay_motors" ? flippableMotors : flippableProducts).map((product) => (
                        <EnhancedProductCard key={product.id} product={product} />
                      ))}
                    </div>
                  ) : (
                    <div className="glass-card">
                      <div className="p-12 text-center">
                        <p className="text-white/80 font-open-sans text-lg">
                          No flippable products found matching your criteria.
                        </p>
                        <p className="text-white/60 text-sm mt-2">Try adjusting your filters or search terms</p>
                      </div>
                    </div>
                  )}
                </TabsContent>

                <TabsContent value="repairable">
                  <div className="mb-6">
                    <div className="flex items-center gap-3 max-w-xs">
                      <Filter className="w-5 h-5 text-white" />
                      <Select
                        value={repairFilter}
                        onValueChange={(value: RepairLevel | "all") => setRepairFilter(value)}
                      >
                        <SelectTrigger className="glass-input border-0 bg-white/20 backdrop-blur-md text-white h-12">
                          <SelectValue placeholder="Filter by repair level" />
                        </SelectTrigger>
                        <SelectContent className="glass-card border-0">
                          <SelectItem value="all">All Levels</SelectItem>
                          <SelectItem value="beginner">Beginner</SelectItem>
                          <SelectItem value="intermediate">Intermediate</SelectItem>
                          <SelectItem value="expert">Expert</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  {(searchEngine === "ebay_motors" ? repairableMotors : repairableProducts).length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                      {(searchEngine === "ebay_motors" ? repairableMotors : repairableProducts).map((product) => (
                        <EnhancedProductCard key={product.id} product={product} />
                      ))}
                    </div>
                  ) : (
                    <div className="glass-card">
                      <div className="p-12 text-center">
                        <p className="text-white/80 font-open-sans text-lg">
                          No repairable products found matching your criteria.
                        </p>
                        <p className="text-white/60 text-sm mt-2">Try adjusting your filters or search terms</p>
                      </div>
                    </div>
                  )}
                </TabsContent>

                {searchEngine === "ebay_motors" && (
                  <TabsContent value="all-motors">
                    {motorProducts.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                        {motorProducts.map((product) => (
                          <EnhancedProductCard key={product.id} product={product} />
                        ))}
                      </div>
                    ) : (
                      <div className="glass-card">
                        <div className="p-12 text-center">
                          <p className="text-white/80 font-open-sans text-lg">
                            No automotive products found matching your criteria.
                          </p>
                          <p className="text-white/60 text-sm mt-2">Try adjusting your filters or search terms</p>
                        </div>
                      </div>
                    )}
                  </TabsContent>
                )}
              </Tabs>
            </div>
          )}

          {loading && products.length === 0 && (
            <div className="glass-card">
              <div className="p-12 text-center">
                <Loader2 className="w-12 h-12 animate-spin mx-auto mb-4 text-white" />
                <p className="text-white font-semibold text-lg font-open-sans">
                  Analyzing {searchEngine === "ebay_motors" ? "vehicles and parts" : "products"}...
                </p>
                <p className="text-white/70 text-sm mt-2">This may take a moment</p>
              </div>
            </div>
          )}

          {!loading && products.length === 0 && !error && searchQuery && (
            <div className="glass-card">
              <div className="p-12 text-center">
                <p className="text-white/80 font-open-sans text-lg">No products found for "{searchQuery}"</p>
                <p className="text-white/60 text-sm mt-2">Try different search terms or check your spelling</p>
              </div>
            </div>
          )}

          {!loading && products.length > 0 && filteredProducts.length === 0 && (
            <div className="glass-card">
              <div className="p-12 text-center">
                <p className="text-white/80 font-open-sans text-lg">No products meet your profit criteria</p>
                <p className="text-white/60 text-sm mt-2">Try lowering the minimum profit requirements</p>
              </div>
            </div>
          )}
        </div>
      </div>

      <Chatbot />
    </div>
  )
}
