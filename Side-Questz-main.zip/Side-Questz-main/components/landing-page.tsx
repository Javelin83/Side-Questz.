"use client"
import { useActionState } from "react"
import { useFormStatus } from "react-dom"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { signIn, signUp } from "@/lib/actions"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Search, TrendingUp, Calculator, Zap, Shield, Loader2, Smartphone, MessageSquare } from "lucide-react"

function SignInSubmitButton() {
  const { pending } = useFormStatus()

  return (
    <Button type="submit" disabled={pending} className="w-full glass-button text-white font-semibold">
      {pending ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Signing in...
        </>
      ) : (
        "Start Your Search"
      )}
    </Button>
  )
}

function SignUpSubmitButton() {
  const { pending } = useFormStatus()

  return (
    <Button type="submit" disabled={pending} className="w-full glass-button text-white font-semibold">
      {pending ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Creating account...
        </>
      ) : (
        "Start Your Search"
      )}
    </Button>
  )
}

export default function LandingPage() {
  const router = useRouter()
  const [signInState, signInAction] = useActionState(signIn, null)
  const [signUpState, signUpAction] = useActionState(signUp, null)

  // Handle successful login by redirecting
  useEffect(() => {
    if (signInState?.success) {
      router.push("/")
    }
  }, [signInState, router])

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 gradient-mesh"></div>

      {/* Floating glass elements */}
      <div className="absolute top-20 left-10 w-32 h-32 glass-morphism rounded-full floating-animation opacity-30"></div>
      <div className="absolute top-40 right-20 w-24 h-24 glass-morphism rounded-full floating-animation-delayed opacity-20"></div>
      <div className="absolute bottom-32 left-1/4 w-40 h-40 glass-morphism rounded-full floating-animation opacity-25"></div>
      <div className="absolute bottom-20 right-10 w-28 h-28 glass-morphism rounded-full floating-animation-delayed opacity-30"></div>

      {/* Header */}
      <header className="relative z-10 border-b border-white/20 bg-white/10 backdrop-blur-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="h-10 w-10 glass-morphism rounded-xl flex items-center justify-center">
                <Search className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-3xl font-black text-white">Side Questz</h1>
            </div>
            <div className="flex items-center space-x-3">
              <Button
                variant="outline"
                size="sm"
                className="glass-morphism border-white/30 text-white hover:bg-white/20 transition-all duration-200 bg-transparent"
                onClick={() =>
                  window.open(
                    "https://docs.google.com/forms/d/e/1FAIpQLSeMG1FPji138DZ6K_zz0r304IfhoDa3pr0r7JkoMjVVMU1JTw/viewform?usp=header",
                    "_blank",
                  )
                }
              >
                <MessageSquare className="h-4 w-4 mr-2" />
                Feedback
              </Button>
              <Badge
                className="backdrop-blur-sm text-white font-medium px-3 py-1"
                style={{
                  backgroundColor: "rgba(34, 197, 94, 0.2)",
                  borderColor: "rgba(74, 222, 128, 0.5)",
                  border: "1px solid rgba(74, 222, 128, 0.5)",
                }}
              >
                Free AI Analysis
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="relative z-10 container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left side - Hero content */}
          <div className="space-y-10">
            <div className="space-y-6">
              <h2 className="text-5xl font-black text-white leading-tight">
                Discover Hidden Treasures — Flip Your Finds with Confidence!
              </h2>
              <p className="text-xl text-white/90 leading-relaxed">
                Find undervalued products, calculate realistic profits including all fees, and make informed flipping
                decisions with our intelligent AI-powered analysis tools.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 items-start">
              <Button
                className="glass-button text-white font-semibold px-6 py-3 flex items-center space-x-3 hover:scale-105 transition-transform"
                onClick={() => window.open("https://median.co/share/abqqeqb", "_blank")}
              >
                <Smartphone className="h-5 w-5" />
                <span>Download Android App</span>
              </Button>
            </div>

            {/* Features */}
            <div className="grid sm:grid-cols-2 gap-6">
              <div className="flex items-start space-x-4">
                <div className="h-12 w-12 glass-morphism rounded-xl flex items-center justify-center flex-shrink-0">
                  <TrendingUp className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-lg">Market Analysis</h3>
                  <p className="text-white/80">AI-powered product research and market valuations</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="h-12 w-12 glass-morphism rounded-xl flex items-center justify-center flex-shrink-0">
                  <Calculator className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-lg">Profit Calculator</h3>
                  <p className="text-white/80">Realistic calculations including all eBay fees</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="h-12 w-12 glass-morphism rounded-xl flex items-center justify-center flex-shrink-0">
                  <Zap className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-lg">Smart Filtering</h3>
                  <p className="text-white/80">Filter by profit margins and repair difficulty</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="h-12 w-12 glass-morphism rounded-xl flex items-center justify-center flex-shrink-0">
                  <Shield className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h3 className="font-bold text-white text-lg">Risk Assessment</h3>
                  <p className="text-white/80">Identify flippable vs repairable items</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right side - Auth forms */}
          <div className="flex justify-center">
            <Card className="w-full max-w-md glass-morphism border-white/20 shadow-2xl">
              <CardHeader className="text-center">
                <CardTitle className="text-white text-2xl">Get Started</CardTitle>
                <CardDescription className="text-white/80">
                  Sign in to access AI-powered eBay flip analysis
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="signin" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 glass-morphism border-white/20">
                    <TabsTrigger value="signin" className="text-white data-[state=active]:bg-white/20">
                      Sign In
                    </TabsTrigger>
                    <TabsTrigger value="signup" className="text-white data-[state=active]:bg-white/20">
                      Sign Up
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="signin" className="space-y-4">
                    {signInState?.error && (
                      <Alert variant="destructive" className="glass-morphism border-red-400/50">
                        <AlertDescription className="text-white">{signInState.error}</AlertDescription>
                      </Alert>
                    )}

                    <form action={signInAction} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="signin-email" className="text-white font-semibold">
                          Email
                        </Label>
                        <Input
                          id="signin-email"
                          name="email"
                          type="email"
                          placeholder="Enter your email"
                          required
                          className="glass-input text-white placeholder:text-white/60"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="signin-password" className="text-white font-semibold">
                          Password
                        </Label>
                        <Input
                          id="signin-password"
                          name="password"
                          type="password"
                          placeholder="Enter your password"
                          required
                          className="glass-input text-white placeholder:text-white/60"
                        />
                      </div>
                      <SignInSubmitButton />
                    </form>
                  </TabsContent>

                  <TabsContent value="signup" className="space-y-4">
                    {signUpState?.error && (
                      <Alert variant="destructive" className="glass-morphism border-red-400/50">
                        <AlertDescription className="text-white">{signUpState.error}</AlertDescription>
                      </Alert>
                    )}

                    {signUpState?.success && (
                      <Alert className="glass-morphism border-green-400/50">
                        <AlertDescription className="text-white">{signUpState.success}</AlertDescription>
                      </Alert>
                    )}

                    <form action={signUpAction} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="signup-email" className="text-white font-semibold">
                          Email
                        </Label>
                        <Input
                          id="signup-email"
                          name="email"
                          type="email"
                          placeholder="Enter your email"
                          required
                          className="glass-input text-white placeholder:text-white/60"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="signup-password" className="text-white font-semibold">
                          Password
                        </Label>
                        <Input
                          id="signup-password"
                          name="password"
                          type="password"
                          placeholder="Create a password (min 6 characters)"
                          required
                          className="glass-input text-white placeholder:text-white/60"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="signup-confirm-password" className="text-white font-semibold">
                          Confirm Password
                        </Label>
                        <Input
                          id="signup-confirm-password"
                          name="confirmPassword"
                          type="password"
                          placeholder="Confirm your password"
                          required
                          className="glass-input text-white placeholder:text-white/60"
                        />
                      </div>
                      <SignUpSubmitButton />
                    </form>
                  </TabsContent>
                </Tabs>

                <div className="mt-6 text-center">
                  <p className="text-white/80 font-medium">Start finding profitable flips in seconds</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
