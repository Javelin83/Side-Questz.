import { createClient, isSupabaseConfigured } from "@/lib/supabase/server"
import LandingPage from "@/components/landing-page"
import AppShell from "@/components/app-shell"

export default async function Home() {
  // If Supabase is not configured, show setup message directly
  if (!isSupabaseConfigured) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gray-50">
        <h1 className="text-2xl font-bold mb-4 text-gray-900">Connect Supabase to get started</h1>
      </div>
    )
  }

  const supabase = await createClient()
  const {
    data: { session },
  } = await supabase.auth.getSession()

  // Show landing page if not authenticated
  if (!session) {
    return <LandingPage />
  }

  // Show main app if authenticated
  return <AppShell />
}
