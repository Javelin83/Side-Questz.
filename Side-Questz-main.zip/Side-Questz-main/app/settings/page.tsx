"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ArrowLeft, Save, Eye, EyeOff } from "lucide-react"
import Link from "next/link"

interface AppSettings {
  groq_api_key?: string
  openai_api_key?: string
  serpapi_key?: string
  gemini_api_key?: string // Added Gemini API key
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<AppSettings>({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null)
  const [showKeys, setShowKeys] = useState({
    groq: false,
    openai: false,
    serpapi: false,
    gemini: false, // Added Gemini visibility toggle
  })
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const checkAuth = async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession()
      if (!session) {
        router.push("/")
        return
      }

      try {
        const response = await fetch("/api/settings")
        if (response.ok) {
          const data = await response.json()
          setSettings(data)
        }
      } catch (error) {
        console.error("Failed to load settings:", error)
      }
      setLoading(false)
    }

    checkAuth()
  }, [router, supabase.auth])

  const handleSave = async () => {
    setSaving(true)
    setMessage(null)

    try {
      const response = await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(settings),
      })

      if (response.ok) {
        setMessage({ type: "success", text: "Settings saved successfully!" })
      } else {
        const error = await response.json()
        setMessage({ type: "error", text: error.error || "Failed to save settings" })
      }
    } catch (error) {
      setMessage({ type: "error", text: "Failed to save settings" })
    }

    setSaving(false)
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center gradient-mesh">
        <div className="text-center glass-morphism p-8 rounded-2xl">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-white font-semibold">Loading settings...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen relative overflow-hidden">
      <div className="absolute inset-0 gradient-mesh"></div>

      <div className="relative z-10 container mx-auto px-4 py-8 max-w-3xl">
        <Link href="/app">
          <Button variant="ghost" className="mb-6 text-white hover:bg-white/20">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to App
          </Button>
        </Link>

        <Card className="glass-morphism border-white/20">
          <CardHeader>
            <CardTitle className="text-2xl text-white">API Settings</CardTitle>
            <CardDescription className="text-white/70">
              Configure your API keys for AI-powered features. Gemini is recommended for best results.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {message && (
              <Alert
                className={
                  message.type === "success" ? "bg-green-500/20 border-green-500/50" : "bg-red-500/20 border-red-500/50"
                }
              >
                <AlertDescription className="text-white">{message.text}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="gemini-key" className="text-white flex items-center gap-2">
                Google Gemini API Key
                <span className="text-xs bg-green-500/20 text-green-300 px-2 py-0.5 rounded">Recommended</span>
              </Label>
              <div className="flex gap-2">
                <Input
                  id="gemini-key"
                  type={showKeys.gemini ? "text" : "password"}
                  placeholder="AIza..."
                  value={settings.gemini_api_key || ""}
                  onChange={(e) => setSettings({ ...settings, gemini_api_key: e.target.value })}
                  className="glass-morphism border-white/20 text-white placeholder:text-white/50"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowKeys({ ...showKeys, gemini: !showKeys.gemini })}
                  className="text-white hover:bg-white/20"
                >
                  {showKeys.gemini ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              <p className="text-xs text-white/60">
                Get your free API key from{" "}
                <a
                  href="https://aistudio.google.com/app/apikey"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="underline"
                >
                  Google AI Studio
                </a>
                . Free tier includes 1,500 requests per day.
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="groq-key" className="text-white">
                Groq API Key (Alternative)
              </Label>
              <div className="flex gap-2">
                <Input
                  id="groq-key"
                  type={showKeys.groq ? "text" : "password"}
                  placeholder="gsk_..."
                  value={settings.groq_api_key || ""}
                  onChange={(e) => setSettings({ ...settings, groq_api_key: e.target.value })}
                  className="glass-morphism border-white/20 text-white placeholder:text-white/50"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowKeys({ ...showKeys, groq: !showKeys.groq })}
                  className="text-white hover:bg-white/20"
                >
                  {showKeys.groq ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              <p className="text-xs text-white/60">
                Get your API key from{" "}
                <a href="https://console.groq.com" target="_blank" rel="noopener noreferrer" className="underline">
                  console.groq.com
                </a>
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="openai-key" className="text-white">
                OpenAI API Key (Optional)
              </Label>
              <div className="flex gap-2">
                <Input
                  id="openai-key"
                  type={showKeys.openai ? "text" : "password"}
                  placeholder="sk-..."
                  value={settings.openai_api_key || ""}
                  onChange={(e) => setSettings({ ...settings, openai_api_key: e.target.value })}
                  className="glass-morphism border-white/20 text-white placeholder:text-white/50"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowKeys({ ...showKeys, openai: !showKeys.openai })}
                  className="text-white hover:bg-white/20"
                >
                  {showKeys.openai ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              <p className="text-xs text-white/60">
                Get your API key from{" "}
                <a href="https://platform.openai.com" target="_blank" rel="noopener noreferrer" className="underline">
                  platform.openai.com
                </a>
              </p>
            </div>

            <div className="space-y-2">
              <Label htmlFor="serpapi-key" className="text-white">
                SerpAPI Key
              </Label>
              <div className="flex gap-2">
                <Input
                  id="serpapi-key"
                  type={showKeys.serpapi ? "text" : "password"}
                  placeholder="Your SerpAPI key"
                  value={settings.serpapi_key || ""}
                  onChange={(e) => setSettings({ ...settings, serpapi_key: e.target.value })}
                  className="glass-morphism border-white/20 text-white placeholder:text-white/50"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => setShowKeys({ ...showKeys, serpapi: !showKeys.serpapi })}
                  className="text-white hover:bg-white/20"
                >
                  {showKeys.serpapi ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </Button>
              </div>
              <p className="text-xs text-white/60">
                Get your API key from{" "}
                <a href="https://serpapi.com" target="_blank" rel="noopener noreferrer" className="underline">
                  serpapi.com
                </a>
              </p>
            </div>

            <Button onClick={handleSave} disabled={saving} className="w-full bg-white/20 hover:bg-white/30 text-white">
              <Save className="mr-2 h-4 w-4" />
              {saving ? "Saving..." : "Save Settings"}
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
