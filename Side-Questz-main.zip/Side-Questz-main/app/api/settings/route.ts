import { type NextRequest, NextResponse } from "next/server"
import { getAppSettings, updateAppSetting } from "@/lib/app-settings"
import { createClient } from "@/lib/supabase/server"

export async function GET() {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const settings = await getAppSettings()
    return NextResponse.json(settings)
  } catch (error) {
    console.error("Settings GET error:", error)
    return NextResponse.json({ error: "Failed to fetch settings" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const supabase = await createClient()
    const {
      data: { user },
    } = await supabase.auth.getUser()

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const body = await request.json()
    const { groq_api_key, openai_api_key, serpapi_key, gemini_api_key } = body

    // Update each setting if provided
    if (gemini_api_key !== undefined) {
      await updateAppSetting("gemini_api_key", gemini_api_key)
    }
    if (groq_api_key !== undefined) {
      await updateAppSetting("groq_api_key", groq_api_key)
    }
    if (openai_api_key !== undefined) {
      await updateAppSetting("openai_api_key", openai_api_key)
    }
    if (serpapi_key !== undefined) {
      await updateAppSetting("serpapi_key", serpapi_key)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Settings POST error:", error)
    return NextResponse.json({ error: "Failed to update settings" }, { status: 500 })
  }
}
