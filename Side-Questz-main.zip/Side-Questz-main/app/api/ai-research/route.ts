import { type NextRequest, NextResponse } from "next/server"
import { researchProductValue } from "@/lib/ai-research"
import { getApiKey } from "@/lib/app-settings"
import { checkRateLimit } from "@/lib/rate-limit"

export async function POST(request: NextRequest) {
  try {
    const ipAddress = request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || "unknown"
    const rateLimit = await checkRateLimit(ipAddress)

    if (!rateLimit.allowed) {
      return NextResponse.json(
        {
          error: "Rate limit exceeded",
          message: `You've reached your daily limit of 50 AI research requests. Resets at ${rateLimit.resetAt.toLocaleTimeString()}.`,
          remaining: 0,
          resetAt: rateLimit.resetAt.toISOString(),
        },
        { status: 429 },
      )
    }

    const { title, condition, price, originalSellingPrice } = await request.json()

    if (!title || !price) {
      return NextResponse.json({ error: "Title and price are required" }, { status: 400 })
    }

    const geminiKey = (await getApiKey("gemini_api_key"))?.trim()
    const groqKey = (await getApiKey("groq_api_key"))?.trim()

    let apiKey: string | undefined
    let provider: "gemini" | "groq" = "gemini"

    if (geminiKey) {
      apiKey = geminiKey
      provider = "gemini"
      console.log("[v0] Using Gemini API key")
    } else if (groqKey) {
      apiKey = groqKey
      provider = "groq"
      console.log("[v0] Using Groq API key")
    }

    if (!apiKey) {
      console.error("No API key configured")
      return NextResponse.json(
        {
          error: "API key not configured",
          message: "Please add your Gemini or Groq API key in Settings",
        },
        { status: 503 },
      )
    }

    const research = await researchProductValue(
      title,
      condition || "used",
      price,
      originalSellingPrice,
      apiKey,
      provider,
    )

    return NextResponse.json({
      ...research,
      rateLimit: {
        remaining: rateLimit.remaining,
        resetAt: rateLimit.resetAt.toISOString(),
      },
    })
  } catch (error: any) {
    console.error("AI research API error:", error)

    if (error?.message?.includes("Invalid API Key")) {
      return NextResponse.json(
        {
          error: "Invalid API Key",
          message: "The API key is invalid. Please check your API key in Settings.",
        },
        { status: 401 },
      )
    }

    return NextResponse.json(
      { error: "Failed to research product", message: error?.message || "Unknown error" },
      { status: 500 },
    )
  }
}
