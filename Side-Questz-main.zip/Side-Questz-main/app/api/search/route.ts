import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams
  const query = searchParams.get("q")
  const engine = searchParams.get("engine") || "ebay" // Default to regular eBay

  if (!query) {
    return NextResponse.json({ error: "Query parameter is required" }, { status: 400 })
  }

  const apiKey = process.env.SERPAPI_KEY

  if (!apiKey) {
    return NextResponse.json({ error: "SerpAPI key not configured" }, { status: 500 })
  }

  try {
    const url = new URL("https://serpapi.com/search")

    if (engine === "ebay_motors") {
      url.searchParams.set("engine", "ebay")
      url.searchParams.set("ebay_domain", "ebay.com")
      url.searchParams.set("_nkw", query)
      url.searchParams.set("_sacat", "6000") // eBay Motors category
    } else {
      url.searchParams.set("engine", "ebay")
      url.searchParams.set("_nkw", query)
    }

    url.searchParams.set("api_key", apiKey)
    url.searchParams.set("num", "20")

    const response = await fetch(url.toString())

    if (!response.ok) {
      throw new Error(`SerpAPI request failed: ${response.status}`)
    }

    const data = await response.json()

    return NextResponse.json(data)
  } catch (error) {
    console.error("Search API error:", error)
    return NextResponse.json({ error: "Failed to fetch search results" }, { status: 500 })
  }
}
