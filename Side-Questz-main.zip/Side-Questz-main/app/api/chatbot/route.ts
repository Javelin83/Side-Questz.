import { type NextRequest, NextResponse } from "next/server"
import { getChatbotResponse } from "@/lib/ai-research"
import { getApiKey } from "@/lib/app-settings"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { message, context } = body

    if (!message) {
      return NextResponse.json({ error: "Message is required" }, { status: 400 })
    }

    const apiKey = (await getApiKey("groq_api_key")) || process.env.GROQ_API_KEY

    const response = await getChatbotResponse(message, context, apiKey)

    return NextResponse.json({ response })
  } catch (error) {
    console.error("Chatbot API error:", error)

    // Return a fallback response instead of an error
    return NextResponse.json({
      response:
        "I'm having trouble processing your request right now. For eBay flipping advice, I recommend starting with familiar product categories, researching completed listings, and always calculating all costs including eBay fees (~10-13%) and shipping.",
    })
  }
}
