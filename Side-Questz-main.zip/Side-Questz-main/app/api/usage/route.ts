import { type NextRequest, NextResponse } from "next/server"
import { getRemainingUses } from "@/lib/rate-limit"

export async function GET(request: NextRequest) {
  try {
    const ipAddress = request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || "unknown"
    const remaining = await getRemainingUses(ipAddress)

    return NextResponse.json({ remaining, limit: 50 })
  } catch (error) {
    console.error("Usage API error:", error)
    return NextResponse.json({ error: "Failed to fetch usage" }, { status: 500 })
  }
}
